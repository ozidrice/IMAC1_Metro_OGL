#include "monde/jeu.h"

int main(int argc, char const *argv[])
{
	if(afficheMenu() == 1)
		return EXIT_SUCCESS;
	return EXIT_FAILURE;
}
