#ifndef _JEU_
#define _JEU_

#include "affichage/menu.h"
#include "monde/monde.h"
#include "props/element.h"

/*
*	Lance une partie
*   @return : 
*       0 si fail 
*       1 si success
*/
int launch();

#endif
